# ontologies--bcn-congress ontology
This ontology is part of the Databus Archivo - A Web-Scale OntologyInterface for Time-Based and SemanticArchiving and Developing Good Ontologies

La Ontología de elementos del Congreso Nacional de Chile entrega un modelo de clases y propiedades que modelan la estructura y funcionamiento del Congreso.
