# Parliamentary biographies ontology
This ontology is part of the Databus Archivo - A Web-Scale OntologyInterface for Time-Based and SemanticArchiving and Developing Good Ontologies

Esta ontologia modela en rdfs y owl clases y relaciones en el dominio de biografias de parlamentarios. 
