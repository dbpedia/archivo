# Object with states ontology
This ontology is part of the Databus Archivo - A Web-Scale OntologyInterface for Time-Based and SemanticArchiving and Developing Good Ontologies

Ontology including the content ontology design pattern for modelling objects with states.
