# The Eurobau Utility Ontology
This ontology is part of the Databus Archivo - A Web-Scale OntologyInterface for Time-Based and SemanticArchiving and Developing Good Ontologies

This ontology provides utility elements for describing building materials and respective offerings from the Eurobau semantic dataspace.
