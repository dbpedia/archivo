# The NASA QUDT Units Ontology
This ontology is part of the Databus Archivo - A Web-Scale OntologyInterface for Time-Based and SemanticArchiving and Developing Good Ontologies

The NASA Units Ontology (N1 or base) provides a vocabulary for describing units of measure. It also contains a limited set of individual units of measure, specifically, those units that do not have, at the moment, a dedicated N2 level  ontology.
