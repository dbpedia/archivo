# Test-Driven RDF Validation Ontology
This ontology is part of the Databus Archivo - A Web-Scale OntologyInterface for Time-Based and SemanticArchiving and Developing Good Ontologies

http://rdfunit.aksw.org/ns/rdfunit_ontology_diagram.png
