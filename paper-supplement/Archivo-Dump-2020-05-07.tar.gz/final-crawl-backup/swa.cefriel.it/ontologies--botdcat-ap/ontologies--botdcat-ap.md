# BotDCAT-AP - Data Catalogue vocabulary Application Profile for chatbots
This ontology is part of the Databus Archivo - A Web-Scale OntologyInterface for Time-Based and SemanticArchiving and Developing Good Ontologies

A vocabulary to describe data sources in a way they can be easily reused and accessed by chatbots.
