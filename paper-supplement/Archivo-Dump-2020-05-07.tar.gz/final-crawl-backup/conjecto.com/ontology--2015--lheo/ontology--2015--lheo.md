# Langage Harmonisé d'Échange d'informations sur l'Offre de formation 
This ontology is part of the Databus Archivo - A Web-Scale OntologyInterface for Time-Based and SemanticArchiving and Developing Good Ontologies

LHÉO est un langage de référence commun de description de l'information sur l'offre de formation. Ce langage minimal permet d'exprimer de façon cohérente une action de formation qui peut ensuite être lue, diffusée, classée et décrite par le plus grand nombre.
