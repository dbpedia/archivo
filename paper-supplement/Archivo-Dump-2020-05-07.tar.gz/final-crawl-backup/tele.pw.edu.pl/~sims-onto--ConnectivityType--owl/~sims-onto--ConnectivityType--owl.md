# ~sims-onto--ConnectivityType--owl ontology
This ontology is part of the Databus Archivo - A Web-Scale OntologyInterface for Time-Based and SemanticArchiving and Developing Good Ontologies

Defines types of connectivity used in communication and bearer services accessible in certain connectivity.
