# DarwinCore Area Ontology
This ontology is part of the Databus Archivo - A Web-Scale OntologyInterface for Time-Based and SemanticArchiving and Developing Good Ontologies

This is a preliminary ontology that may or may not move into a version of the DarwinCore vocabulary. It has been created for testing purposes and should be considered unstable.
