# TaxonConcept Mammalia Ontology
This ontology is part of the Databus Archivo - A Web-Scale OntologyInterface for Time-Based and SemanticArchiving and Developing Good Ontologies

This is an ontology for the taxonomic clades within the biological class Mammalia to the subfamily level
