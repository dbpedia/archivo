# TaxonConcept People Ontology
This ontology is part of the Databus Archivo - A Web-Scale OntologyInterface for Time-Based and SemanticArchiving and Developing Good Ontologies

This is a simple foaf based list of people.
