# ontology--Arpenteur--owl ontology
This ontology is part of the Databus Archivo - A Web-Scale OntologyInterface for Time-Based and SemanticArchiving and Developing Good Ontologies


	Arpenteur ontology is dedicated to photogrammetry, archeology and oceanology communities 
	in order to perform tasks such as image processing, photogrammetry and modelling.
	Website: http://www.arpenteur.org

	v. 0.0.1: general ontology dedicated to photogrammetric survey and measured object.
	v. 0.0.2: Now unified ontology for photogrammetry and measured items.
	v. 0.0.3: Adding PetraData Class to manage several Siti.
	v. 0.0.4: Starting using time from CRM for stratigraphy.
	v. 0.0.5: Adding ashlar Bloc to stratigraphy.
	v. 0.0.5: Cancelling all FunctionalProperties.
	v. 0.0.6: Now Element coming from Architecture have a link toward a stratigraphic Unit.
	v. 0.0.7: Adding Stratigraphic relation between two ElementoStratigrafico.
			Before this version these relation was done with ID.
	v. 0.0.8: All link with E54 relation from CRM CIDOC are commented.
	v. 0.0.9: Introduction to redCoral.
	v. 0.0.10: Changing BoundingBoxParallel to BoundingBox.
	v. 0.0.11: Connecting GeoSPARQL ontology: SpatialObject, IPoint.
	v. 0.0.12: Modeling Plane Objects for 2D Plane Locatization.
	v. 0.0.13: Modeling datatypes properties for amphorae to match the typologies
	Rhodian, Thasian, Koan, Mushroom Rim and Chian. Acknowledgment 
	to Laboratory (MARE Lab) of the University of Cyprus team.
	v. 0.0.14: Modeling Intervals and Directions 
	
