# Erlangen FRBRoo
This ontology is part of the Databus Archivo - A Web-Scale OntologyInterface for Time-Based and SemanticArchiving and Developing Good Ontologies

Changelog:
121016 (Justyna Walkowska)
- R4 has been disconnected from P128
- R11 has been disconnected from R16 and P33
- R26 has been disconnected from both P2 and P108
120219 (Judith Merges)
- Initial version
