# Erlangen CRM / OWL
This ontology is part of the Databus Archivo - A Web-Scale OntologyInterface for Time-Based and SemanticArchiving and Developing Good Ontologies

Changelog: https://github.com/erlangen-crm/ecrm/commits/master
