# formats--oboInOwl ontology
This ontology is part of the Databus Archivo - A Web-Scale OntologyInterface for Time-Based and SemanticArchiving and Developing Good Ontologies

OBO Format metamodel. This meta-ontology is self-describing. OBO metamodel properties are described using OBO metamodel properties
