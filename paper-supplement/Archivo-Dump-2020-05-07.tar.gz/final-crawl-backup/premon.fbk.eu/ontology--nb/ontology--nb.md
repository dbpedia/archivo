# Predicate Model for Ontologies (PreMOn) - NomBank ontology module
This ontology is part of the Databus Archivo - A Web-Scale OntologyInterface for Time-Based and SemanticArchiving and Developing Good Ontologies

http://premon.fbk.eu/images/nb.svg
