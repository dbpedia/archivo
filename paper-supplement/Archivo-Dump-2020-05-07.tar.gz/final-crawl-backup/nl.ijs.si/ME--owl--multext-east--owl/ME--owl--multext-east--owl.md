# ME--owl--multext-east--owl ontology
This ontology is part of the Databus Archivo - A Web-Scale OntologyInterface for Time-Based and SemanticArchiving and Developing Good Ontologies

OLiA annotation model for the morphosyntactic specifications of MULTEXT-East v. 4. (Erjavec 2010). Unless marked otherwise, all comments refer to this document.<br/>

Additionally, Qasemizadeh & Rahimi (2006), Dimitrova et al. (2009) and Derzhanski & Kotsyba (2009) were consulted for clarification. Email communication with Tomaž Erjavec, Serge Sharoff, Dan Tufis, Ivan A. Derzhanski, Natalia Kosyba, Csaba Oravecz and Hamidreza Kobdani represents the third source of information consulted for this ontology.<br/>

References:<br/>

Ivan Derzhanski, Natalia Kotsyba (2009), Towards a Consistent Morphological Tagset for Slavic Languages: Extending MULTEXT-East for Polish, Ukrainian and Belarusian, In: Proc. MONDILEX Third Open Workshop
Bratislava, Slovakia, 15–16 April, 2009, p. 9-26<br/>

Ludmila Dimitrova, Radovan Garabík, Daniela Majchráková (2009), Comparing Bulgarian and Slovak Multext-East morphology tagset, In: Proceedings of MONDILEX Second Open Workshop, Kyiv, Ukraine, 2–4 February, 2009, p. 38-46<br/>

Tomaž Erjavec (ed., 2010),  MULTEXT-East Morphosyntactic Specifications Version 4. 2010-05-12, http://nl.ijs.si/ME/V4/msd/html/index.html<br/>

Behrang Qasemizadeh and Saeed Rahimi (2006), Persian in MULTEXT-East Framework, in T. Salakoski et al. (eds.): FinTAL 2006, LNAI 4139, pp. 541 – 551, 2006.
