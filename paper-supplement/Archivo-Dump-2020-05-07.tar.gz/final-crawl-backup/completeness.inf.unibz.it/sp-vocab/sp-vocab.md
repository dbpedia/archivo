# SP-statements Vocabulary
This ontology is part of the Databus Archivo - A Web-Scale OntologyInterface for Time-Based and SemanticArchiving and Developing Good Ontologies

The vocabulary for SP-statements, i.e., statements about data completeness of entity-centric KBs (e.g., Wikidata).
