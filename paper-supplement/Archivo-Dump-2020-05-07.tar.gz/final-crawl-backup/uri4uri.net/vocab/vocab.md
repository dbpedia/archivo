# URI Vocabulary
This ontology is part of the Databus Archivo - A Web-Scale OntologyInterface for Time-Based and SemanticArchiving and Developing Good Ontologies

This vocabulary describes the entities which may be derived from a URI and the relationships between them, such as Internet Domains, prototcols, file suffixes etc. It was initially issued as part of an April 1st gag, but has utility beyond the initial joke.
